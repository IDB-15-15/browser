#ifndef NETWORK
#define NETWORK

#include <string>
#include <iostream>
#include <vector>


std::vector<std::string> geth(std::string site);


#endif // NETWORK

